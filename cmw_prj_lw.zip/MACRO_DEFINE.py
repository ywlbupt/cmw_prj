#!/usr/bin/env python
# -*- coding: utf-8 -*-

from collections import namedtuple

ue_struct_l = namedtuple("ue_struct_l",['BAND','CH_UL','CH_DL','BW'])
ue_struct_w = namedtuple("ue_struct_w",['w_BAND','w_CH_UL','w_CH_DL'])

LTE_BW_5="B050"
LTE_BW_10="B100"
LTE_BW_20="B200"
LOW_CHANNEL = 0
MID_CHANNEL = 1
HIGH_CHANNEL = 2

class str_ue_info_l():
    def __init__(self, ue_struct_):
        self.BAND=ue_struct_[0]
        self.CH_UL=ue_struct_[1]
        self.CH_DL=ue_struct_[2]
        self.BW=ue_struct_[3]

    def __str__(self):
        return "B{band:0>2}\t{ch_ul:5}\t{bw:d}MHz".format(band=self.BAND[2:],ch_ul=self.CH_UL,bw=int(int(self.BW[1:])/10))

class str_ue_info_w():
    def __init__(self, ue_struct_):
        self.BAND=ue_struct_[0]
        self.CH_UL=ue_struct_[1]
        self.CH_DL=ue_struct_[2]

    def __str__(self):
        return "B{band:0>2}\t{ch_ul:5}".format(band=self.BAND[2:],ch_ul=self.CH_UL)
